<?php
 
$config['callback_url'] = 'https://berenjgilani.ir/connect/linkedin/linkedin_check.php'; //callback URL
$config['Client_ID'] = '78azi0ag587jme'; // LinkedIn Application Client ID
$config['Client_Secret'] = 'Iro7See1h8HIFZF4';  // LinkedIn Application 
?>
