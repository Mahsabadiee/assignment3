<?php
require_once('config.php');
require_once('file_config.php');
session_start();
// Google passes a parameter 'code' in the Redirect Url
if(isset($_GET['code'])) {
	try {
	    
		$gapi = new GoogleLoginApi();
		
		// Get the access token 
		$data = $gapi->GetAccessToken(CLIENT_ID, CLIENT_REDIRECT_URL, CLIENT_SECRET, $_GET['code']);
		
		// Get user information
		$user_info = $gapi->GetUserProfileInfo($data['access_token']);
        $email = $user_info['email'];
        include('connect.php');
        $sql = "SELECT * FROM `patient` WHERE email = ?";
        $query = $connect->prepare($sql);
        $query->bindValue(1,$email);
        $query->execute();
        if($query->rowCount() == 0)
        {
           
        $prescription = ['Use of the drug Safinamide','Use as needed Co-beneldopa','Pramipexole as recommended','Biperiden tablets','Prepare the drug selegiline as needed'];
        $size2 = count($prescription);
        $count2 = $size2 - 1;
        $rand2 = rand(0,$count2);
        $note = $prescription[$rand2];
 		    
        $sql2 = "SELECT * FROM `medicine` where `medicineID` = ?";
        $query2 = $connect->prepare($sql2);
        $query2->bindValue(1,rand(1,6));
        $query2->execute();
        $value2 = $query2->fetch(PDO::FETCH_OBJ);
        $random = rand(1,6);
        $rand = 'data'.$random;
        
        $loc_ip = $_SERVER['REMOTE_ADDR'];
        
        $location = json_decode(file_get_contents('http://api.ipstack.com/'.$loc_ip.'?access_key=f66600893f98df60ee220d052901c396'));
        $geolocation = $location->latitude.','.$location->longitude;
        $datadosage = rand(200,1000);
        $sql3 = 'INSERT INTO `patient`(`id`, `username`, `email`, `note`, `medicine`, `dosage`, `data`, `location`) VALUES (null,?,?,?,?,?,?,?)';
         
        $query3 = $connect->prepare($sql3);
        $query3->bindValue(1,$user_info['name']);
        $query3->bindValue(2,$email);
        $query3->bindValue(3,$note);
        $query3->bindValue(4,$value2->name);
        $query3->bindValue(5,$datadosage);
        $query3->bindValue(6,$rand);
        $query3->bindValue(7,$geolocation);

        if($query3->execute())
        {
            
                $_SESSION["username"]=$user_info['name'];
                $_SESSION["email"]=$email;
                $_SESSION["note"]=$note;
                $_SESSION["medicine"]=$value2->name;
                $_SESSION["dosage"]=$datadosage;
                $_SESSION["data"]=$rand;
                $_SESSION["location"]=$geolocation;
                header('Location:../show/patients/patient.php');
                exit();
        }
        
        }
        
        
        else
        {

				$value = $query->fetch(PDO::FETCH_OBJ);
                $_SESSION["username"]=$value->username;
                $_SESSION["email"]=$value->email;
                $_SESSION["note"]=$value->note;
                $_SESSION["medicine"]=$value->medicine;
                $_SESSION["dosage"]=$value->dosage;
                $_SESSION["data"]=$value->data;
                $_SESSION["location"]=$value->location;
                header('Location:../show/patients/patient.php');
                exit();
               
        }
        

//$sql = "SELECT u.userID, u.username, u.email, u.Role_IDrole, u.Organization, u.Lat, u.Long, r.name as r_name, r.type as r_type FROM user u LEFT JOIN `role` r ON u.Role_IDrole = r.roleID WHERE email='$email'";
//$result = $conn->query($sql);

            
	}
	catch(Exception $e) {
		echo $e->getMessage();
		exit();
	}
}
    	
    	/*
		// Get user information
 		    $prescription = ['Use of the drug Safinamide','Use as needed Co-beneldopa','Pramipexole as recommended','Biperiden tablets','Prepare the drug selegiline as needed'];
 		    $size2 = count($prescription);
 		    $count2 = $size2 - 1;
 		    $rand2 = rand(0,$count2);
 		    $note = $prescription[$rand2];
 		    $doctor = ['Dr.james' , 'Dr.saman','Dr.ahmad','Dr.janatan','Dr.danny'];
 		    $username = ['james' , 'saman','ahmad','janatan','danny'];
 		    $email = ['hamed@gmail.com' , 'samanian@gmail.com','mohammad_sazi@gmail.com','deljoo@gmail.com','profesor@gmail.com'];
 		    
 		    $location = ['astaneh ashrafieh' , 'new yourk','abadan','landon','porto','berlin' , 'paris','lahijan','poland','russia'];
 		    $size1 = count($username);
            $size = count($doctor);
            $count1 = $size-1;
            $count2 = $size1-1;
            $d = rand(0,$count1);
            $d2 = rand(0,$count2);
            $name = $doctor[$d];
            $user_account = $username[$d2];
            $emails = $email[$d2];
 		    $dosage = rand(100,400);
 		    $random = rand(1,6);
 		    $rand_loc = rand(1,9);
 		    $rand = 'data'.$random.'.csv';
            $sql = "INSERT INTO `patient`(`id`, `username`, `email`, `note`, `medicine`, `dosage`, `data`,`location`) VALUES (null,?,?,?,?,?,?,?)";
			$result2 = $connect->prepare($sql);
			$result2->bindValue(1,$user_account);
			$result2->bindValue(2,$emails);
			$result2->bindValue(3,$note);
			$result2->bindValue(4,$name);
			$result2->bindValue(5,$dosage);
			$result2->bindValue(6,$rand);
			$result2->bindValue(7,$location[$rand_loc]);
			if($result2->execute())
			{
			session_start();
            $_SESSION["username"]=$user_account;
            $_SESSION["dataURL"]=$rand;
            header('Location:../show/patients/patient.php');
			    
			}
            */
	    

/*
  // get profile info
  $google_oauth = new Google_Service_Oauth2($client);
  $google_account_info = $google_oauth->userinfo->get();
  $email =  $google_account_info->email;

  // now you can use this profile info to create account in your website and make user logged in.
} else {
  echo "<a href='".$client->createAuthUrl()."'>Google Login</a>";
}




*/


?>