<?php
/*
include('vendor/autoload.php');

$google_client = new Google_Client();

$google_client->setClientId('671723584738-ar3k82v9hnopgid5f9s5vcbpm8p7ssca.apps.googleusercontent.com');

$google_client->setClientSecret('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');

$google_client->setRedirectUri('https://berenjgilani.ir/connect/googlelogin/google_check.php');

$google_client->addScope('email');

$google_client->addScope('profile');

$guzzleClient = new \GuzzleHttp\Client(array( 'curl' => array( CURLOPT_SSL_VERIFYPEER => false, ), ));

$google_client->setHttpClient($guzzleClient);
*/

define('CLIENT_ID', '671723584738-ar3k82v9hnopgid5f9s5vcbpm8p7ssca.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', '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');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'https://berenjgilani.ir/connect/googlelogin/google_check.php');

?>