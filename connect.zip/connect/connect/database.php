<?php
 $dbhost = "localhost";
 $dbuser = "berenjgi_connect";
 $dbpass = "09014615171m";
 $db = "berenjgi_database";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);

 if ($conn->connect_error) {
    echo $conn->connect_error;
}

?>
