<?php
$connect = new PDO("mysql:host=localhost;dbname=berenjgi_database","berenjgi_connect","09014615171m");
$connect->exec('set names utf8');
?>