<?php
$config1['callback_url'] = 'https://berenjgilani.ir/connect/githublogin/gitcheck.php';
$config1['Client_ID'] = 'Iv1.72301fd3d67b4866';
$config1['Client_Secret'] = 'cc6b5714773218c0f36347336cf0766b3105e89e';
?>
